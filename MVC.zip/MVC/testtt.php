<div class="form1">




                        <div class="textfonts">Travel class-TRRRR</div>
                        <br>
                        <label class="container">
                            <input type="checkbox">First Class
                            <span class="checkmark"></span>
                        </label><br>
                        <label class="container">
                            <input type="checkbox">Business Class
                            <span class="checkmark"></span>
                        </label><br>
                        <label class="container">
                            <input type="checkbox">Premium Economy
                            <span class="checkmark"></span>
                        </label><br>
                        <label class="container">
                            <input type="checkbox">Economy Class
                            <span class="checkmark"></span>
                        </label><br>
                        <label class="container">
                            <input type="checkbox">Economy Class
                            <span class="checkmark"></span>
                        </label><br>
                        <label class="container">
                            <input type="checkbox">Economy Class
                            <span class="checkmark"></span>
                        </label><br>
                        <label class="container">
                            <input type="checkbox">Economy Class
                            <span class="checkmark"></span>
                        </label><br>
                        <label class="container">
                            <input type="checkbox">Premium Economy
                            <span class="checkmark"></span>
                        </label><br>
                        <label class="container">
                            <input type="checkbox">Economy Class
                            <span class="checkmark"></span>
                        </label><br>
                        <label class="container">
                            <input type="checkbox">Economy Class
                            <span class="checkmark"></span>
                        </label><br>
                        <label class="container">
                            <input type="checkbox">Economy Class
                            <span class="checkmark"></span>
                        </label><br>
                        <label class="container">
                            <input type="checkbox">Economy Class
                            <span class="checkmark"></span>
                        </label><br>




                </div>
