<?php

$dbServerName = "localhost";
$dbUsername = "root";
$dbPass = "";
$dbName = "TripInspire";

$conn = mysqli_connect($dbServerName, $dbUsername, $dbPass, $dbName);

// echo "succees";


 ?>
